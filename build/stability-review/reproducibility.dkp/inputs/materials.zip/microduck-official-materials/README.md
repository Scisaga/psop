# Microduck 官方来源资料

本包保留官方来源的中文设备与操作说明、可逐个打开的官方 STL 外形文件，以及 HAT C1 电路板、板级零件清单和元件位置对照资料。**STL 版本尚未与本包 alpha 硬件配置对应，未验证可打印装配。**

## 从这里找资料

| 位置 | 内容与用途 |
| --- | --- |
| [01-设备信息](01-设备信息/README.md) | alpha 配置的主控、电池、传感器接口、15 个关节名称与 ID；一张官网外观照片 |
| [02-操作手册](02-操作手册/README.md) | 对应官方软件版本的状态检查、手柄配对、控制、更新及局部排错 |
| [03-三维模型](03-三维模型/README.md) | 38 个 STL、中文文件名及来源索引；用于查看零件外形，不作为已验证的打印或整机装配图纸 |
| [04-HAT板级BOM与电路](04-HAT板级BOM与电路/README.md) | 官方 HAT C1 的两份中文表、两份 PDF 和板卡 STEP；可按元件位号对应，尚未确认适配 alpha 整机 |
| [官方平衡恢复演示.mp4](官方平衡恢复演示.mp4) | 约 12.5 秒的官方动作演示 |

## 哪些 STL 不需要打印

制作能实际运行的机器人时，至少以下 **8 个 STL 对应的功能器件不列为普通塑料 3D 打印件**。这些文件用于查看器件外形和模型中的位置，打印出的外形不能代替真实器件；点击文件名可打开对应模型。

| STL 文件 | 对应部件 | 实际使用方式 |
| --- | --- | --- |
| [xl330_XL330舵机外形.stl](03-三维模型/assets/xl330_XL330舵机外形.stl) | XL330 舵机 | 使用实体舵机 |
| [np_f970_NP-F970电池外形.stl](03-三维模型/assets/np_f970_NP-F970电池外形.stl) | 电池 | 使用实体电池 |
| [pcb__raspberry_pi_zero_2_w_树莓派Zero2W电路板外形.stl](03-三维模型/assets/pcb__raspberry_pi_zero_2_w_树莓派Zero2W电路板外形.stl) | 主控板 | 使用实体主控板 |
| [elec_rpi_robot_hat_pcb_RPIRobotHAT电路板外形.stl](03-三维模型/assets/elec_rpi_robot_hat_pcb_RPIRobotHAT电路板外形.stl) | HAT 电路板 | 使用制造并完成元件装配的电路板 |
| [lens_镜头外形.stl](03-三维模型/assets/lens_镜头外形.stl) | 镜头 | 使用实体镜头 |
| [speaker_扬声器外形.stl](03-三维模型/assets/speaker_扬声器外形.stl) | 扬声器 | 使用实体扬声器 |
| [seeed_bearing__configuration__22x16x4_轴承外形-22×16×4.stl](03-三维模型/assets/seeed_bearing__configuration__22x16x4_轴承外形-22×16×4.stl) | 22×16×4 轴承外形 | 使用实体轴承 |
| [seeed_bearing__configuration_default_轴承外形-默认配置.stl](03-三维模型/assets/seeed_bearing__configuration_default_轴承外形-默认配置.stl) | 默认配置轴承外形 | 使用实体轴承 |

**8 个指模型文件种类，不是整机采购数量；本表是依据器件用途整理的说明，不是官方发布的打印清单。** 原文件及来源见 [模型部件索引](03-三维模型/模型部件索引.csv)。树莓派 Zero 2W、NP-F970 等模型名称不能作为本包 alpha 配置的采购型号。

**其余 30 个 STL 也不能直接全部认定为打印件。** 镜头座、加强板、软质件等尚缺明确的官方制造方式和材料说明，整套 STL 未验证可打印装配。`bearing_roll_横滚轴承支承件.stl` 是独立支承结构，与表中的两类轴承外形不同，不归入上述 8 个器件模型。

## 版本和文件之间的关系

- **设备与操作说明**：固定到官方软件提交 `4861141fdc7c7acd253671acf5abdd55b77b779e`，采用 alpha 配置：Radxa Zero 3W、NP-F550、15 个 XL330 系列舵机和 imu_to_dxl v2 身体姿态板。
- **STL 外形**：固定到官方模型仓库提交 `cb70b792312d559a4da09064d92009079671815f`。这是另一份官方模型快照，与 alpha 的制造版本尚未对应；主控、电池等外形名称不能作为 alpha 的采购型号。
- **HAT C1 板级资料**：固定到官方电路板仓库提交 `88d51faf7f5fcc845d2e3b42d4f05ebb98b963b9`，用于独立查元件与电路；不是已确认的 alpha 整机电控方案，也不是整机 BOM。
- 关节 ID 见 [关节名称与 ID](01-设备信息/关节名称与ID.md)；模型文件名与中文含义见 [STL 目录](03-三维模型/assets/README.md)。两者尚未建立同一实机版本的逐件装配对应，不凭相近名称直接合并。
- 官网照片和视频用于外观与动作参考，不用于确认内部硬件或制造修订版。

目前没有收录运动学 XML 或仿真场景。38 个 STL 可独立打开查看；它们包含结构件与外购电子器件的外形，**不能全部当成需打印的零件**。HAT 的外形 STL 也不能证明采用某个板卡制造修订版；04 中的 C1 图纸和清单作为独立板级参考保留，不与该 STL 或 alpha 配置直接合并。

当前仍未取得对应 alpha 的完整整机 BOM、制造 CAD、整机接线与装配工艺，以及实机标定和验收规程。现有 STL 和 HAT 板级资料不表示这些整机缺项已经补齐。

## 来源与许可

- 配置：[官方控制设计](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/docs/design/robotd-design.md)、[主控实机记录](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/docs/project/media-bringup.md)。
- 操作与关节：[操作速查](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/docs/robot/cheatsheet.md)、[关节 ID 定义](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/duck-control/src/model.rs)、[关节名称定义](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/duck-ipc-proto/src/lib.rs)。中文为依据官方内容的翻译与整理，不是厂家中文版；软件仓库许可见 [官方 LICENSE](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/LICENSE)。
- STL：[官方网格目录](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets)、[原始模型](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/robot_walk.xml)。保留网格原件内容，仅文件名追加中文；逐个文件来源见子目录 README。官方将三维文件单独声明为 [Creative Commons BY-SA-NC](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/README.md#license)，该声明未注明许可版本，不按软件的 Apache 2.0 许可处理。
- HAT C1：[官方板卡仓库](https://github.com/pollen-robotics/elec_RPI_Robot_HAT/blob/88d51faf7f5fcc845d2e3b42d4f05ebb98b963b9/README.md)、[官方 BOM](https://github.com/pollen-robotics/elec_RPI_Robot_HAT/blob/88d51faf7f5fcc845d2e3b42d4f05ebb98b963b9/production/ASE01187-C1_elec_RPI_Robot_HAT_BOM.csv)、[官方许可](https://github.com/pollen-robotics/elec_RPI_Robot_HAT/blob/88d51faf7f5fcc845d2e3b42d4f05ebb98b963b9/LICENSE)。PDF、STEP 保留原件内容；两份中文表为依据官方原表与图纸的整理，具体来源见 04 README。
- 媒体：[官方媒体页](https://pollen-robotics.com/microduck/press-kit/)、[照片原件](https://pollen-robotics.com/assets/microduck/press/photos/microduck-closeup.jpg)、[视频原件](https://pollen-robotics.com/assets/microduck/gallery/balance-recovery.mp4)，采集于 2026-09-23，文件未修改。媒体下载入口不等于模型训练授权。

各子目录 README 保留来源链接；未收录社区复刻资料、程序源码或模型权重。
