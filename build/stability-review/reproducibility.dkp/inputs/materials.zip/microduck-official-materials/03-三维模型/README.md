# 官方 STL 三维外形

**版本尚未与 alpha 硬件对应，未验证可打印装配。**本目录恢复官方模型快照中的全部 38 个 STL，供逐个打开查看外形；不将它们称为经过确认的 3D 打印工程。

| 位置 | 内容 |
| --- | --- |
| [assets](assets/README.md) | 38 个 STL，文件名附中文识别名称；每个文件都有官方来源链接 |
| [模型部件索引.csv](模型部件索引.csv) | 文件名、中文名称、原始模型中的可视实例数与所属刚体、官方出处 |

没有收录 `robot_walk.xml` 或场景 XML。单个 STL 可用支持 STL 的三维查看器或切片软件打开，但文件中不包含装配顺序、紧固件规格或运动控制。

## 这些文件分别表示什么

- **结构与外壳**：头部壳体、躯干底座、腿部、脚部和连接支架等。
- **现成器件的外形**：舵机、主控板、电池、HAT 电路板、轴承、镜头和扬声器等。这些网格用于表示外形，不能当作要用塑料打印的电子元件。
- **中文名称**：为方便识别而整理，不是厂家制造件编号或材料规范；原英文文件标识保留。

原模型中包含 `pcb__raspberry_pi_zero_2_w`、`np_f970` 和 `elec_rpi_robot_hat_pcb`，分别表示树莓派 Zero 2 W、电池及 HAT 外形。它们不替代 [alpha 设备说明](../01-设备信息/设备说明.md) 中的 Radxa Zero 3W 和 NP-F550，也不能据此确定 HAT 为 C1 板。此处保留真实原文件名，不通过改名掩盖差异。 [04 中的 HAT C1 图纸与板级清单](../04-HAT板级BOM与电路/README.md)作为独立参考保留，尚未与这里的板卡外形确定制造版本对应关系。

## 索引中的数量和关系怎么读

索引统计来自同一官方快照的 [原始模型 XML](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/robot_walk.xml)：38 个不同 STL 被引用为 70 个可视实例。实例数不是整机采购数量；所属刚体是原仿真模型中的名称，不是装配步骤或官方制造总成编号。

例如，`xl330.stl` 会在多个部位重复使用。CSV 中的数量和所属刚体说明它在原模型中如何出现；不能因此认定全部网格与本包 alpha 软件关节 ID 一一对应。索引不再附加跨版本的软件 ID 映射。

## 打印前的限制

官方发布的是用于仿真的外形网格，导出配置启用了网格简化。本包没有确认打印材料、壁厚、安装孔、间隙、强度、缩放或整机配合，也没有提供切片工程。

STL 本身不记录长度单位。上游模型按米制使用这些坐标；导入默认按毫米解释的工具时，需要核对尺寸，不能仅凭文件成功打开就打印。这里没有对网格做缩放、修补或重新设计。

## 官方来源与许可

- 固定来源：`microduck_rl` 提交 `cb70b792312d559a4da09064d92009079671815f` 的 [网格目录](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets)。
- 数量和所属刚体依据：[原始模型](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/robot_walk.xml)。这里只保留来源链接，本地不收录 XML。
- 导出与单位背景：[官方导出配置](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/config_mjcf_walk.json)、[原始模型](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/robot_walk.xml)。
- [官方模型许可声明](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/README.md#license)：三维模型为 **Creative Commons BY-SA-NC**，该段未注明版本。STL 原件内容不变；中文文件名、中文说明和索引属于本地整理。
