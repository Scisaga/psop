# STL 文件

本目录保留官方步行模型引用的 38 个 STL。**版本尚未与本包 alpha 硬件对应，未验证可打印装配。**文件名采用“原英文名_中文识别名.stl”，便于在文件列表中直接辨认。STL 网格内容未修改；本包只保留外形文件，不收录模型 XML。中文名称是整理名称，不是官方制造件编号。

## 先按用途辨认

| 类别 | 例子 | 看什么 |
| --- | --- | --- |
| 壳体与结构 | 头部上壳、躯干底座、左右大腿和脚部 | 部件外形与机械空间关系 |
| 支承与连接 | 电机支架、颈部件、偏航与横滚连接件 | 部件之间的连接和支承外形 |
| 现成器件的外形 | XL330 舵机、电池、电路板、镜头、扬声器 | 安装占位和辨认参考，不是电子器件的打印文件 |

同一文件可能在机器人模型中出现多次。查原模型中的可视实例数、所属刚体，使用 [模型部件索引](../模型部件索引.csv)；查索引用途和版本限制，见 [上级说明](../README.md)。这些关系只属于原官方模型，未与 alpha 软件 ID 建立装配对应；不能只看文件名决定采购数量或打印材料。

## 文件与来源

| 当前文件 | 官方原文件名 | 中文识别名称 | 来源 |
| --- | --- | --- | --- |
| [ankle_left_左踝部件.stl](ankle_left_左踝部件.stl) | `ankle_left.stl` | 左踝部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/ankle_left.stl) |
| [ankle_right_右踝部件.stl](ankle_right_右踝部件.stl) | `ankle_right.stl` | 右踝部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/ankle_right.stl) |
| [banana_pcb_locker_电路板固定件.stl](banana_pcb_locker_电路板固定件.stl) | `banana_pcb_locker.stl` | 电路板固定件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/banana_pcb_locker.stl) |
| [bearing_roll_横滚轴承支承件.stl](bearing_roll_横滚轴承支承件.stl) | `bearing_roll.stl` | 横滚轴承支承件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/bearing_roll.stl) |
| [bottom_head_shell_头部下壳.stl](bottom_head_shell_头部下壳.stl) | `bottom_head_shell.stl` | 头部下壳 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/bottom_head_shell.stl) |
| [elec_rpi_robot_hat_pcb_RPIRobotHAT电路板外形.stl](elec_rpi_robot_hat_pcb_RPIRobotHAT电路板外形.stl) | `elec_rpi_robot_hat_pcb.stl` | RPI Robot HAT 电路板外形 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/elec_rpi_robot_hat_pcb.stl) |
| [face_part_面部件.stl](face_part_面部件.stl) | `face_part.stl` | 面部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/face_part.stl) |
| [foot_left_左脚部件.stl](foot_left_左脚部件.stl) | `foot_left.stl` | 左脚部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/foot_left.stl) |
| [foot_right_右脚部件.stl](foot_right_右脚部件.stl) | `foot_right.stl` | 右脚部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/foot_right.stl) |
| [hip_l_髋部件.stl](hip_l_髋部件.stl) | `hip_l.stl` | 髋部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/hip_l.stl) |
| [jaw_喙部件.stl](jaw_喙部件.stl) | `jaw.stl` | 喙部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/jaw.stl) |
| [jaw_soft_喙部软质件.stl](jaw_soft_喙部软质件.stl) | `jaw_soft.stl` | 喙部软质件（文件名标识） | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/jaw_soft.stl) |
| [left_shell_左侧外壳.stl](left_shell_左侧外壳.stl) | `left_shell.stl` | 左侧外壳 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/left_shell.stl) |
| [leg_腿部连杆.stl](leg_腿部连杆.stl) | `leg.stl` | 腿部连杆 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/leg.stl) |
| [lens_镜头外形.stl](lens_镜头外形.stl) | `lens.stl` | 镜头外形 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/lens.stl) |
| [m12_lens_holder_M12镜头座.stl](m12_lens_holder_M12镜头座.stl) | `m12_lens_holder.stl` | M12 镜头座 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/m12_lens_holder.stl) |
| [motor_support_电机支架.stl](motor_support_电机支架.stl) | `motor_support.stl` | 电机支架 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/motor_support.stl) |
| [neck_颈部件.stl](neck_颈部件.stl) | `neck.stl` | 颈部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/neck.stl) |
| [neck_pitch_颈俯仰部件.stl](neck_pitch_颈俯仰部件.stl) | `neck_pitch.stl` | 颈俯仰部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/neck_pitch.stl) |
| [noenoeil_眼部部件.stl](noenoeil_眼部部件.stl) | `noenoeil.stl` | 眼部部件（文件名标识） | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/noenoeil.stl) |
| [np_f970_NP-F970电池外形.stl](np_f970_NP-F970电池外形.stl) | `np_f970.stl` | NP-F970 电池外形 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/np_f970.stl) |
| [pcb__raspberry_pi_zero_2_w_树莓派Zero2W电路板外形.stl](pcb__raspberry_pi_zero_2_w_树莓派Zero2W电路板外形.stl) | `pcb__raspberry_pi_zero_2_w.stl` | 树莓派 Zero 2 W 电路板外形 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/pcb__raspberry_pi_zero_2_w.stl) |
| [power_support_电源支架.stl](power_support_电源支架.stl) | `power_support.stl` | 电源支架 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/power_support.stl) |
| [right_shell_右侧外壳.stl](right_shell_右侧外壳.stl) | `right_shell.stl` | 右侧外壳 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/right_shell.stl) |
| [seeed_bearing__configuration__22x16x4_轴承外形-22×16×4.stl](seeed_bearing__configuration__22x16x4_轴承外形-22×16×4.stl) | `seeed_bearing__configuration__22x16x4.stl` | 轴承外形（22×16×4 配置名） | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/seeed_bearing__configuration__22x16x4.stl) |
| [seeed_bearing__configuration_default_轴承外形-默认配置.stl](seeed_bearing__configuration_default_轴承外形-默认配置.stl) | `seeed_bearing__configuration_default.stl` | 轴承外形（默认配置名） | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/seeed_bearing__configuration_default.stl) |
| [soft_mouth_top_喙上部软质件.stl](soft_mouth_top_喙上部软质件.stl) | `soft_mouth_top.stl` | 喙上部软质件（文件名标识） | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/soft_mouth_top.stl) |
| [sole_left_左脚底.stl](sole_left_左脚底.stl) | `sole_left.stl` | 左脚底 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/sole_left.stl) |
| [sole_right_右脚底.stl](sole_right_右脚底.stl) | `sole_right.stl` | 右脚底 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/sole_right.stl) |
| [speaker_扬声器外形.stl](speaker_扬声器外形.stl) | `speaker.stl` | 扬声器外形 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/speaker.stl) |
| [top_head_shell_头部上壳.stl](top_head_shell_头部上壳.stl) | `top_head_shell.stl` | 头部上壳 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/top_head_shell.stl) |
| [trunk_base_躯干底座.stl](trunk_base_躯干底座.stl) | `trunk_base.stl` | 躯干底座 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/trunk_base.stl) |
| [upper_leg_left_左大腿部件.stl](upper_leg_left_左大腿部件.stl) | `upper_leg_left.stl` | 左大腿部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/upper_leg_left.stl) |
| [upper_leg_right_右大腿部件.stl](upper_leg_right_右大腿部件.stl) | `upper_leg_right.stl` | 右大腿部件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/upper_leg_right.stl) |
| [upper_leg_rigidity_plate_大腿加强板.stl](upper_leg_rigidity_plate_大腿加强板.stl) | `upper_leg_rigidity_plate.stl` | 大腿加强板 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/upper_leg_rigidity_plate.stl) |
| [xl330_XL330舵机外形.stl](xl330_XL330舵机外形.stl) | `xl330.stl` | XL330 舵机外形 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/xl330.stl) |
| [yaw2roll_偏航与横滚连接件.stl](yaw2roll_偏航与横滚连接件.stl) | `yaw2roll.stl` | 偏航与横滚连接件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/yaw2roll.stl) |
| [yaw_roll_motion_偏航与横滚传动件.stl](yaw_roll_motion_偏航与横滚传动件.stl) | `yaw_roll_motion.stl` | 偏航与横滚传动件 | [官方来源](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets/yaw_roll_motion.stl) |

来源版本：`microduck_rl` 提交 `cb70b792312d559a4da09064d92009079671815f`。原始目录：[官方 assets](https://github.com/pollen-robotics/microduck_rl/blob/cb70b792312d559a4da09064d92009079671815f/src/mjlab_microduck/robot/microduck/assets)。

用途、单位及模型许可见 [上级说明](../README.md)；这些文件不是一套已经验证的 3D 打印工程。
