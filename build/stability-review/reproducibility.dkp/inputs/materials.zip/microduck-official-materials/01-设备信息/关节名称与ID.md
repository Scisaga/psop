# 关节名称与 ID

适用对象：官方 `microduck` 仓库的 **alpha** 配置，提交 `4861141fdc7c7acd253671acf5abdd55b77b779e`。中文名称为对应术语的中文整理。

| 数组索引（从 0 开始） | 舵机总线 ID | 官方关节名称 | 中文名称 |
| --- | --- | --- | --- |
| 0 | 20 | `left_hip_yaw` | 左髋偏航 |
| 1 | 21 | `left_hip_roll` | 左髋横滚 |
| 2 | 22 | `left_hip_pitch` | 左髋俯仰 |
| 3 | 23 | `left_knee` | 左膝 |
| 4 | 24 | `left_ankle` | 左踝 |
| 5 | 30 | `neck_pitch` | 颈俯仰 |
| 6 | 31 | `head_pitch` | 头俯仰 |
| 7 | 32 | `head_yaw` | 头偏航 |
| 8 | 33 | `head_roll` | 头横滚 |
| 9 | 34 | `mouth` | 喙开合 |
| 10 | 10 | `right_hip_yaw` | 右髋偏航 |
| 11 | 11 | `right_hip_roll` | 右髋横滚 |
| 12 | 12 | `right_hip_pitch` | 右髋俯仰 |
| 13 | 13 | `right_knee` | 右膝 |
| 14 | 14 | `right_ankle` | 右踝 |

- 总线 ID 是与舵机通信时使用的地址，不是图片编号，也不是三维文件编号。
- 15 个物理关节包含喙；官方 alpha 策略输出为 14 个动作，不包含索引 9 的喙开合。两种数量不能混用。
- 身体 IMU 桥接板另使用总线 ID `200`，不属于这 15 个关节。
- 本表来自软件配置，不是用户实机标定记录。安装方向、零位与机械限位应与具体硬件和官方配置共同确认。

## 与三维外形资料的关系

本表对应官方 alpha 软件配置；[03-三维模型](../03-三维模型/README.md)中的 STL 来自另一份官方模型快照，尚未确认属于同一实机版本。本表不把软件 ID 直接映射成 STL 文件、采购编号或安装位置。

## 来源

- [官方关节 ID、默认姿态及 IMU ID 定义](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/duck-control/src/model.rs)。
- [官方关节名称定义](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/duck-ipc-proto/src/lib.rs)。

以上来源固定到提交 `4861141fdc7c7acd253671acf5abdd55b77b779e`；中文关节名称为本地整理。
