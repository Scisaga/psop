# 设备信息

这一部分统一使用 **Microduck 官方 alpha 配置**：Radxa Zero 3W、NP-F550 和 v2 身体姿态板。设备与关节说明来自同一官方软件版本；官网照片只作外观参考。

| 文件 | 内容 |
| --- | --- |
| [设备说明.md](设备说明.md) | 选定的 alpha 硬件、主控与传感器接口及官方依据 |
| [关节名称与ID.md](关节名称与ID.md) | 官方 alpha 配置中的 15 个关节、舵机 ID 和控制索引 |
| [官方整机照片.jpg](官方整机照片.jpg) | 官网整机照片，保持原图 |

## 如何使用这三个文件

1. 先看 [设备说明](设备说明.md)，了解本包选用的计算平台、电池、关节与传感器接口。表中保留有官方 alpha 依据的信息，不是完整整机采购 BOM。
2. 对照 [官方整机照片](官方整机照片.jpg)，观察头部、颈部、躯干、腿和脚的大致形态。单张外观照片不能确定内部接线或每个零件的规格。
3. 再看 [关节名称与 ID](关节名称与ID.md)，把左髋、右膝、颈部等名称与控制地址对应起来。ID 是软件与舵机通信使用的编号，不是模型文件序号或 PCB 元件位号。

例如，表中的 `20` 对应左髋偏航舵机；查它如何检查或控制，进入 [02-操作手册](../02-操作手册/README.md)；查看官方模型的部件外形，进入 [03-三维模型](../03-三维模型/README.md)；这些 STL 尚未确认与 alpha 配置对应。

## 来源

- alpha 硬件范围：[官方控制设计](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/docs/design/robotd-design.md)、[主控实机记录](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/docs/project/media-bringup.md)。
- 外观照片：[Pollen Robotics 官方媒体资料页](https://pollen-robotics.com/microduck/press-kit/)，采集日期 2026-09-23。
- 照片：[官方原文件](https://pollen-robotics.com/assets/microduck/press/photos/microduck-closeup.jpg)。
- 关节：[官方 model.rs](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/duck-control/src/model.rs)，提交 `4861141fdc7c7acd253671acf5abdd55b77b779e`。

中文文档为官方来源的中文整理，不是原厂中文文档。官网产品照片不是特定实机的标定或验收记录；关节配置不能直接套用于社区飞特改版。
