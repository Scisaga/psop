# 操作手册

本目录根据官方软件文档编写中文摘选，适用于本包选定的官方 alpha 配置及对应软件版本。这里的 `robotctl` 命令应在机器人上执行；普通服务器仅保存资料时不需要执行。

| 文件 | 内容 |
| --- | --- |
| [操作与检查.md](操作与检查.md) | 适用硬件与固件、版本检查、手柄和关节操作、更新、软件与传感器逐项检查 |
| [故障排查与舵机更换.md](故障排查与舵机更换.md) | 官方已有的排错入口、固件通信排查及单个舵机替换说明 |

未取得厂家完整装配、拆解、紧固扭矩、定期保养、逐项标定或出厂验收手册，故本目录不编造这些规程。

## 两份手册分别解决什么问题

- **操作与检查**：已有机器人和对应软件后，如何查看版本与健康状态、连接手柄、初始化关节、进行基本控制和软件更新。它描述正常操作及检查入口。
- **故障排查与舵机更换**：出现手柄不响应、舵机无响应或更新问题时，从哪里查看状态和日志；以及官方软件如何识别单个替换舵机。它没有补齐机械拆卸、接线和紧固工艺。

阅读顺序是“版本与状态 → 手柄连接 → 关节初始化与基本控制 → 异常排查”。逐项检查的输出含义和初始化与标定的区别已并入 [操作与检查](操作与检查.md)。具体命令及动作前提在对应正文中；初始化会移动关节，释放关节会失去支撑，应按原文要求放置或扶住机器人。

涉及“哪个关节”时，查 [关节名称与 ID](../01-设备信息/关节名称与ID.md)；查看部件外形可进入 [三维模型](../03-三维模型/README.md)，但其版本尚未与 alpha 配置对应，不能作为本手册的装配依据。这两份手册不是从散件装成整机的装配说明书。

## 来源

- [官方操作速查](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/docs/robot/cheatsheet.md)
- [官方手柄配对说明](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/docs/robot/pair-a-gamepad.md)
- [官方关节和总线配置](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/duck-control/src/model.rs)

- [官方运行配置](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/deploy/robotd.toml)：硬件通信条件与默认开关。

以上均固定到提交 `4861141fdc7c7acd253671acf5abdd55b77b779e`。中文说明是整理稿；上游许可为 [Apache 2.0](https://github.com/pollen-robotics/microduck/blob/4861141fdc7c7acd253671acf5abdd55b77b779e/LICENSE)。
